<?php
     // include database connection file
     include("koneksi.php");
    // Check If form submitted, insert form data into users table.
    if(isset($_POST['submit'])) {
        $kode = $_POST['kode'];
        $nama = $_POST['nama'];
        $jenis = $_POST['jenis'];
        $jumlah = $_POST['jumlah'];
        $harga = $_POST['harga'];
        $pengambil = $_POST['pengambil'];
        $kode_warna = $_POST['kode_warna'];

        // Insert user data into table
        $result = mysqli_query($conn, "INSERT INTO barang(kode_barang,nama_barang,jenis,jumlah,pengambil,harga,kode_warna) VALUES('$kode','$nama','$jenis','$jumlah','$pengambil','$harga','$kode_warna')");
}

if(isset($_POST['submit_edit'])){
    $kode = $_POST['kode'];
    $nama = $_POST['nama'];
    $jenis = $_POST['jenis'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];
    $kode_warna = $_POST['kode_warna'];
	
	$sql	= 'update barang set kode_barang="'.$kode.'", nama_barang="'.$nama.'", jenis="'.$jenis.'", jumlah="'.$jumlah.'", harga="'.$harga.', kode_warna="'.$kode_warna.'';
	$query	= mysqli_query($conn,$sql);
	
	
}
?>