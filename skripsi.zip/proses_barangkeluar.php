<?php
     // include database connection file
     include("koneksi.php");
    // Check If form submitted, insert form data into users table.
    if(isset($_POST['submit'])) {
        $kode = $_POST['kode'];
        $nama = $_POST['nama'];
        $jenis = $_POST['jenis'];
        $jumlah = $_POST['jumlah'];
        $harga = $_POST['harga'];
        $kode_warna = $_POST['kode_warna'];
        $pengambil = $_POST['pengambil'];
        $tanggal = $_POST['tanggal'];

        // Insert user data into table
        $result = mysqli_query($conn, "INSERT INTO barang_keluar(kode_barang,nama_barang,jenis,jumlah,harga,kode_warna,pengambil,tanggal_keluar) VALUES('$kode','$nama','$jenis','$jumlah','$harga','$kode_warna','$pengambil',$tanggal)");
}

if(isset($_POST['submit_edit'])){
    $kode = $_POST['kode'];
    $nama = $_POST['nama'];
    $jenis = $_POST['jenis'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];
    $kode_warna = $_POST['kode_warna'];
	
	$sql	= 'update barang set kode_barang="'.$kode.'", nama_barang="'.$nama.'", jenis="'.$jenis.'", jumlah="'.$jumlah.'", harga="'.$harga.', kode_warna="'.$kode_warna.'';
	$query	= mysqli_query($conn,$sql);
	
	
}
?>