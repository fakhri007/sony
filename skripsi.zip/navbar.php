<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <!-- Left navbar links -->
  <a class="navbar-brand" href="#">
    <img src="assets/dist/img/logo.PNG" width="80" height="70" class="d-inline-block align-top" alt="">
    
  </a> 
  <div class="pl-2 mt-3"> <h3>CV. MUDA MANDIRI</h3></div>
        <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
    <li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
																		<img src="assets/dist/img/user2-160x160.jpg" class="img-circle" width="40px" height="40px"  alt="Administrasi"> 
																
								<span>Administrasi</span> 
								<i class="icon-submenu lnr lnr-chevron-down"></i>
							</a>
							<ul class="dropdown-menu">
								<li><a href=""><i class="lnr lnr-user"></i> <span>Edit Profil</span></a></li>
								<li><a href="logout.php"><i class="lnr lnr-exit"></i> <span>Keluar</span></a></li>
							</ul>
						</li>
    </ul>
  </nav>
  <!-- /.navbar -->